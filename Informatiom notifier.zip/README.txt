## How to use
1. Download chrome driver of the same version as chrome on your computer at https://chromedriver.chromium.org/downloads and 
  put it in the folder where Webpage changes notifier.cmd is.
2. Put any name you want in Webpage name box.
3. Put the address whose change you want to know.
4. What to put in XPath to HTML element box:
  Execute chrome -> Press Ctrl + Shift + C and click on the place whose change you want to know -> Right click on the selected code 
  -> Click on Copy -> Click on Copy XPath
5. Execute Information notifier.cmd


1. https://chromedriver.chromium.org/downloads 에서 자신의 컴퓨터에 있는 chrome과 동일한 chrome driver를 다운로드 받아서 Webpage changes notifier.cmd가 있는 폴더에 넣는다.
2. Webpage name 박스엔 원하는 이름을 넣는다.
3. URL 박스에 변화를 감지하고 싶은 페이지의 주소를 넣는다.
4. XPath to HTML element 박스에 넣을 것 : 
chrome실행 >> 원하는 웹페이지에서 Ctrl + Shift + C 누르고 변화를 감지할 곳을 클릭 >> 선택된 코드에 오른쪽 클릭 >> 복사 >> XPath 복사
5. Information notifier.cmd 실행