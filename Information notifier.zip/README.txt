## How to use
1. Put any name you want in Webpage name box.
2. Put the webpage address you want to keep track on.
3. What to put in Full XPath box:
  Execute chrome -> Press Ctrl + Shift + C and click on the place whose change you want to know -> Right click on the selected part
  -> Click on Copy -> Click on Copy Full XPath
4. Execute Information notifier.cmd

1. Webpage name 박스엔 원하는 이름을 넣는다.
2. URL 박스에 변화를 감지하고 싶은 페이지의 주소를 넣는다.
3. Full XPath 박스에 넣을 것 : 
chrome실행 >> 원하는 웹페이지에서 Ctrl + Shift + C 누르고 변화를 감지할 곳을 클릭 >> 선택된 부분에 오른쪽 클릭 >> 복사 >> Full XPath 복사
4 Information notifier.cmd 실행